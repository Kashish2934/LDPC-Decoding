#include <bits/stdc++.h>
using namespace std;

int main()
{
    int n, u;

    u = 3000;
    n = 5000;

    vector<int> correct(101, 0);
    vector<float> val_cn(3);
    vector<float> val_vn(n);
    vector<vector<pair<int, float>>> cn_graph(u);
    vector<vector<pair<int, float>>> vn_graph(n);
    vector<float> final(n);

    float constant_1, vnd_1, vnd_0;

    int **hmat = new int *[u];

    for (int i = 0; i < u; i++)
    {
        hmat[i] = new int[n];
    }

    ifstream fin;
    fin.open("h_matrix_q3.txt");

    if (!fin)
    {
        cout << "Cannot open the file" << endl;
        exit(0);
    }

    int inRow = 0, inCol = 0;

    char data;
    while (!fin.eof())  // Reading h_matrix_q3 as a text file
                       
    {
        fin >> data;

        if (inCol == n)
        {

            inCol = 0;
            inRow++;
        }

        hmat[inRow][inCol] = data - 48;
        inCol++;

        if (inRow == u - 1 && inCol == n)
        {
            break;
        }
    }
    fin.close();                

    for (int i = 0; i < n; i++)
    {                                                        // Establish connection of VN to CN
        for (int j = 0; j < u; j++)
        {
            if (hmat[j][i] == 1)
            {
                vn_graph[i].push_back({j + 1, -1});
            }
        }
    }

    for (int i = 0; i < u; i++)
    {                                                   // Establish connection of CN to VNs
        for (int j = 0; j < n; j++)
        {
            if (hmat[i][j] == 1)
            {
                cn_graph[i].push_back({j + 1, -1});
            }
        }
    }

    int dv = 0;
	int dc = 0;

	for(int i=0; i<1; i++)       // Find degree of check node
	{
		for(int j=0; j<n; j++)
		{
			if(hmat[i][j] == 1)
			{
				dc++;
			}
		}
	}

	for(int i=0; i<1; i++)         // Find degree of variable node
	{
		for(int j=0; j<u; j++)
		{
			if(hmat[j][i] == 1)
			{
				dv++;
			}
		}
	}

    float probability_array[101]; 

    float p = 0;

    for (int i = 0; i < 101; i++)
    {
        probability_array[i] = p;
        p = p + 0.01;
    }

    srand(time(NULL));

    for (int outer_ind = 0; outer_ind < 101; outer_ind++)
    {
        int Nsim = 1000;

        for (int Nsim_itr = 1; Nsim_itr <= Nsim; Nsim_itr++) // Monte - Carlo Experiment for 1000 times
        {
            vector<int> original_signal(n, 0); // Original Signal
            vector<int> signal_with_noise(n); // Signal with noise

            for (int i = 0; i < n; i++)
            {
                float tpr = ((float)rand() / (RAND_MAX + 1)); // Random number generator

                if (tpr > probability_array[outer_ind])
                {
                    signal_with_noise[i] = original_signal[i];
                }
                else
                {
                    signal_with_noise[i] = -1;
                }

                if (signal_with_noise[i] == 0)
                {
                    val_vn[i] = 0;

                    for (int ci = 0; ci < dv; ci++)
                    {
                        vn_graph[i][ci].second = 0;
                    }
                }
                else
                {
                    val_vn[i] = 0.5;       // Assigning 0.5 as a probability for erasure bits

                    for (int ci = 0; ci < dv; ci++)
                    {
                        vn_graph[i][ci].second = 0.5;
                    }
                }
            }

            int t_flag = 1;
            int zero_erasure_case = 1;
            int itr_cnt = 0;

            while (t_flag != 0 && zero_erasure_case != 9 && itr_cnt < 100)    // Maximum 100 iterations are allowed
            {

                // Sending message to CN from VN

                for (int i = 0; i < n; i++)
                {
                    int c1 = vn_graph[i][0].first;
                    int c2 = vn_graph[i][1].first;
                    int c3 = vn_graph[i][2].first;

                    for (int j = 0; j < dc; j++)
                    {
                        if (cn_graph[c1 - 1][j].first == i + 1)
                        {
                            cn_graph[c1 - 1][j].second = vn_graph[i][0].second;
                        }
                    }
                    for (int j = 0; j < dc; j++)
                    {
                        if (cn_graph[c2 - 1][j].first == i + 1)
                        {
                            cn_graph[c2 - 1][j].second = vn_graph[i][1].second;
                        }
                    }
                    for (int j = 0; j < dc; j++)
                    {
                        if (cn_graph[c3 - 1][j].first == i + 1)
                        {
                            cn_graph[c3 - 1][j].second = vn_graph[i][2].second;
                        }
                    }
                }

                // Sending message to VN from CN
                // Using bernard's equation

                t_flag = 0;
                zero_erasure_case = 0;

                for (int i = 0; i < u; i++)
                {
                    int erasure_count = 0;

                    for (auto it : cn_graph[i])
                    {
                        if (it.second == 0.5)
                        {
                            erasure_count++;
                        }
                    }

                    if (erasure_count == 1)
                    {
                        int cn_itr = 0;

                        for (auto &it : cn_graph[i])
                        {
                            if (it.second == 0.5)
                            {
                                int t_vn;

                                t_vn = it.first;

                                if (cn_itr == 0)
                                {
                                    for (auto &vn_it : vn_graph[t_vn - 1])
                                    {
                                        if (vn_it.first == i + 1)
                                        {
                                            vn_it.second = (0.5 - 0.5 * (1 - 2 * cn_graph[i][1].second) * (1 - 2 * cn_graph[i][2].second) * (1 - 2 * cn_graph[i][3].second) * (1 - 2 * cn_graph[i][4].second));
                                        }
                                    }
                                }
                                else if (cn_itr == 1)
                                {
                                    for (auto &vn_it : vn_graph[t_vn - 1])
                                    {
                                        if (vn_it.first == i + 1)
                                        {
                                            vn_it.second = (0.5 - 0.5 * (1 - 2 * cn_graph[i][0].second) * (1 - 2 * cn_graph[i][2].second) * (1 - 2 * cn_graph[i][3].second) * (1 - 2 * cn_graph[i][4].second));
                                        }
                                    }
                                }
                                else if (cn_itr == 2)
                                {
                                    for (auto &vn_it : vn_graph[t_vn - 1])
                                    {
                                        if (vn_it.first == i + 1)
                                        {
                                            vn_it.second = (0.5 - 0.5 * (1 - 2 * cn_graph[i][0].second) * (1 - 2 * cn_graph[i][1].second) * (1 - 2 * cn_graph[i][3].second) * (1 - 2 * cn_graph[i][4].second));
                                        }
                                    }
                                }
                                else if (cn_itr == 3)
                                {
                                    for (auto &vn_it : vn_graph[t_vn - 1])
                                    {
                                        if (vn_it.first == i + 1)
                                        {
                                            vn_it.second = (0.5 - 0.5 * (1 - 2 * cn_graph[i][0].second) * (1 - 2 * cn_graph[i][1].second) * (1 - 2 * cn_graph[i][2].second) * (1 - 2 * cn_graph[i][4].second));
                                        }
                                    }
                                }
                                else if (cn_itr == 4)
                                {
                                    for (auto &vn_it : vn_graph[t_vn - 1])
                                    {
                                        if (vn_it.first == i + 1)
                                        {
                                            vn_it.second = (0.5 - 0.5 * (1 - 2 * cn_graph[i][0].second) * (1 - 2 * cn_graph[i][1].second) * (1 - 2 * cn_graph[i][2].second) * (1 - 2 * cn_graph[i][3].second));
                                        }
                                    }
                                }
                                t_flag = 1;
                            }

                            cn_itr++;
                        }
                    }
                    else if (erasure_count == 0)
                    {
                        zero_erasure_case++;
                    }
                }

                for (int i = 0; i < n; i++)    // This loop is for compution of Conditional probability for VN would be 1
                {
                    for (int j = 0; j < 3; j++)
                    {
                        val_cn[j] = vn_graph[i][j].second;
                    }

                    for (int j = 0; j < 3; j++)
                    {
                        vnd_1 = val_vn[i] * val_cn[(j + 1) % 3] * val_cn[(j + 2) % 3];   

                        vnd_0 = (1 - val_vn[i]) * (1 - val_cn[(j + 1) % 3]) * (1 - val_cn[(j + 2) % 3]);

                        constant_1 = 1 / (vnd_0 + vnd_1);

                        vn_graph[i][j].second = constant_1 * vnd_1;
                    }
                }

                itr_cnt++;
            }

            t_flag = 0;

            for (int i = 0; i < n; i++)      // Making decision from likelihood ratio
            {
                final[i] = (val_vn[i] / (1 - val_vn[i])) * (vn_graph[i][0].second / (1 - vn_graph[i][0].second)) * (vn_graph[i][1].second / (1 - vn_graph[i][1].second)) * (vn_graph[i][2].second / (1 - vn_graph[i][2].second));

                if (final[i] > 1)    
                {
                    final[i] = 1;
                }
                else if (final[i] == 1)
                {
                    final[i] = 0.5;
                }
                else
                {
                    final[i] = 0;
                }
            }

            for (int i = 0; i < n; i++)      //  Checking with original signal
            {
                if (final[i] != original_signal[i])
                {
                    t_flag++;
                    break;
                }
            }

            if (t_flag == 0)
            {
                correct[outer_ind] = correct[outer_ind] + 1;
            }
        }
    }

    cout << "Probability of Successful Decoding : " << endl;

    cout << endl;

    for (int i = 0; i < 101; i++)
    {
        cout << float(correct[i]) / 1000 << endl;
    }
}
