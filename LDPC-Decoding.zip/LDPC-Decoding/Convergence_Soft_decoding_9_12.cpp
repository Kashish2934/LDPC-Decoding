#include <bits/stdc++.h>      // This code will give the number of erasure bit per iteration
using namespace std;

int find_dc(vector<vector<int>> &hmat, int n, int u)
{
    int dc = 0;

    for (int i = 0; i < 1; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (hmat[i][j] == 1)
            {
                dc++;
            }
        }
    }

    return dc;
}

int find_dv(vector<vector<int>> &hmat, int n, int u)
{
    int dv = 0;

    for (int i = 0; i < 1; i++)
    {
        for (int j = 0; j < u; j++)
        {
            if (hmat[j][i] == 1)
            {
                dv++;
            }
        }
    }

    return dv;
}

void connect_checkNode_with_variableNode(vector<vector<int>> &hmat, int n, int u, vector<vector<pair<int, float>>> &cn_graph)
{
    for (int i = 0; i < u; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (hmat[i][j] == 1)
            {
                cn_graph[i].push_back({j + 1, -1});
            }
        }
    }
}

void connect_variableNode_with_checkNode(vector<vector<int>> &hmat, int n, int u, vector<vector<pair<int, float>>> &vn_graph)
{
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < u; j++)
        {
            if (hmat[j][i] == 1)
            {
                vn_graph[i].push_back({j + 1, -1});
            }
        }
    }
}

int main()
{
    int n, u;

    cout << "Enter Row(u) and Column(n) of H matrix : " << endl;

    cin >> u >> n;

    vector<vector<int>> hmat(u, vector<int>(n, 0));

    vector<vector<pair<int, float>>> cn_graph(u);
    vector<vector<pair<int, float>>> vn_graph(n);

    vector<float> val_vn(n);

    vector<float> final(n);
    vector<float> val_cn(3);

    vector<int> conv(51, 0);

    float probability = 0.6;

    float constant_1, vnd_1, vnd_0;

    cout << "Enter H matrix : " << endl;

    for (int i = 0; i < u; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cin >> hmat[i][j];
        }
    }

    int dc = find_dc(hmat, n, u);
    int dv = find_dv(hmat, n, u);

    connect_checkNode_with_variableNode(hmat, n, u, cn_graph);

    connect_variableNode_with_checkNode(hmat, n, u, vn_graph);

    srand(time(NULL));

    int Nsim = 10000;

    for (int Ksim = 1; Ksim <= Nsim; Ksim++) // Loop for Monte - Carlo simulations
    {

        vector<int> original_signal(n, 0); 

        vector<int> signal_with_noise(n); 

        for (int i = 0; i < n; i++)
        {
            float tpr = ((float)rand() / (RAND_MAX + 1)); // Generating a random number between 0 to 1

            if (tpr > probability)
            {
                signal_with_noise[i] = original_signal[i];
            }
            else
            {
                signal_with_noise[i] = -1; // If generated number is less than or equal to crossover probability p then, it is erasure
            }

            if (signal_with_noise[i] == 0)
            {
                val_vn[i] = 0;

                for (int ci = 0; ci < 3; ci++)
                {
                    vn_graph[i][ci].second = 0;
                }
            }
            else
            {
                val_vn[i] = 0.5;

                for (int ci = 0; ci < 3; ci++)
                {
                    vn_graph[i][ci].second = 0.5;
                }

                conv[0]++;
            }
        }

        int itr_cnt = 0;


        while (itr_cnt < 50)
        {

            for (int i = 0; i < n; i++)
            {
                int c1 = vn_graph[i][0].first;
                int c2 = vn_graph[i][1].first;
                int c3 = vn_graph[i][2].first;

                for (int j = 0; j < dc; j++)
                {
                    if (cn_graph[c1 - 1][j].first == i + 1)
                    {
                        cn_graph[c1 - 1][j].second = vn_graph[i][0].second;
                    }
                }
                for (int j = 0; j < dc; j++)
                {
                    if (cn_graph[c2 - 1][j].first == i + 1)
                    {
                        cn_graph[c2 - 1][j].second = vn_graph[i][1].second;
                    }
                }
                for (int j = 0; j < dc; j++)
                {
                    if (cn_graph[c3 - 1][j].first == i + 1)
                    {
                        cn_graph[c3 - 1][j].second = vn_graph[i][2].second;
                    }
                }
            }

            for (int i = 0; i < u; i++)
            {
                int erasure_count = 0;

                for (auto it : cn_graph[i])
                {
                    if (it.second == 0.5)
                    {
                        erasure_count++;
                    }
                }

                if (erasure_count == 1)
                {
                    int cn_itr = 0;

                    for (auto &it : cn_graph[i])
                    {
                        if (it.second == 0.5)
                        {
                            int t_vn;

                            t_vn = it.first;

                            if (cn_itr == 0)
                            {
                                for (auto &vn_it : vn_graph[t_vn - 1])
                                {
                                    if (vn_it.first == i + 1)
                                    {
                                        vn_it.second = (0.5 - 0.5 * (1 - 2 * cn_graph[i][1].second) * (1 - 2 * cn_graph[i][2].second) * (1 - 2 * cn_graph[i][3].second));
                                    }
                                }
                            }
                            else if (cn_itr == 1)
                            {
                                for (auto &vn_it : vn_graph[t_vn - 1])
                                {
                                    if (vn_it.first == i + 1)
                                    {
                                        vn_it.second = (0.5 - 0.5 * (1 - 2 * cn_graph[i][0].second) * (1 - 2 * cn_graph[i][2].second) * (1 - 2 * cn_graph[i][3].second));
                                    }
                                }
                            }
                            else if (cn_itr == 2)
                            {
                                for (auto &vn_it : vn_graph[t_vn - 1])
                                {
                                    if (vn_it.first == i + 1)
                                    {
                                        vn_it.second = (0.5 - 0.5 * (1 - 2 * cn_graph[i][0].second) * (1 - 2 * cn_graph[i][1].second) * (1 - 2 * cn_graph[i][3].second));
                                    }
                                }
                            }
                            else if (cn_itr == 3)
                            {
                                for (auto &vn_it : vn_graph[t_vn - 1])
                                {
                                    if (vn_it.first == i + 1)
                                    {
                                        vn_it.second = (0.5 - 0.5 * (1 - 2 * cn_graph[i][0].second) * (1 - 2 * cn_graph[i][1].second) * (1 - 2 * cn_graph[i][2].second));
                                    }
                                }
                            }
                        }

                        cn_itr++;
                    }
                }
            }

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    val_cn[j] = vn_graph[i][j].second;
                }

                if (val_cn[0] != 0 && val_cn[1] != 0 && val_cn[2] != 0 && val_vn[i] != 0)
                {
                    conv[itr_cnt + 1]++;
                }

                for (int j = 0; j < 3; j++)
                {
                    vnd_1 = val_vn[i] * val_cn[(j + 1) % 3] * val_cn[(j + 2) % 3];

                    vnd_0 = (1 - val_vn[i]) * (1 - val_cn[(j + 1) % 3]) * (1 - val_cn[(j + 2) % 3]);

                    constant_1 = 1 / (vnd_0 + vnd_1);

                    vn_graph[i][j].second = constant_1 * vnd_1;
                }
            }

            itr_cnt++;
        }
    }

    for (int i = 0; i < 51; i++)
    {
        cout << float(conv[i]) / (Nsim*n) << endl;
    }
}
