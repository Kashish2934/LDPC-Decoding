#include <bits/stdc++.h>
using namespace std;


int find_dc(vector<vector<int>> &hmat, int n, int u)   // This function will find the degree of check node from given H matrix
{	
	int dc = 0;

	for(int i=0; i<1; i++)
	{
		for(int j=0; j<n; j++)
		{
			if(hmat[i][j] == 1)
			{
				dc++;
			}
		}
	}

	return dc;
}

int find_dv(vector<vector<int>> &hmat, int n, int u)   // This function will find the degree of variable node from given H matrix
{	
	int dv = 0;

	for(int i=0; i<1; i++)
	{
		for(int j=0; j<u; j++)
		{
			if(hmat[j][i] == 1)
			{
				dv++;
			}
		}
	}

	return dv;
}

void connect_checkNode_with_variableNode(vector<vector<int>> &hmat, int n, int u, vector<vector<pair<int, int>>> &cn_graph)
{									// This function is for connection of check node with variable node
	for (int i = 0; i < u; i++)
	{
		for (int j = 0; j < n; j++)
		{
			if (hmat[i][j] == 1)
			{
				cn_graph[i].push_back({j + 1, -1});
			}
		}
	}
}

void connect_variableNode_with_checkNode(vector<vector<int>> &hmat, int n, int u, vector<vector<pair<int, int>>> &vn_graph)
{								// This function is for connection of variable node with check node
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < u; j++)
		{
			if (hmat[j][i] == 1)
			{
				vn_graph[i].push_back({j + 1, -1});
			}
		}
	}
}

vector<float> assign_probability(float p)   // This function will assign probability from 0 to 1 with increment of 0.01
{	
	vector<float> prob_arr(101);

	for (int i = 0; i < 101; i++)
	{
		prob_arr[i] = p;

		p = p + 0.01;
	}

	return prob_arr;
}

int main()
{
	int n, u;

	cout << "Enter Row(u) and Column(n) of H matrix : " << endl;
	
	cin >> u >> n;

	vector<vector<int>> hmat(u, vector<int>(n, 0));

	vector<int> correct(101, 0);
	vector<int> val_vn(n);
	vector<vector<pair<int, int>>> cn_graph(u);
	vector<vector<pair<int, int>>> vn_graph(n);
	vector<float> probability_array(101);

	cout << "Enter H matrix : " << endl;
													// Taking input of H matrix
	for (int i = 0; i < u; i++)
	{
		for (int j = 0; j < n; j++)
		{
			cin >> hmat[i][j];
		}
	}


	int dc = find_dc(hmat, n, u);
	int dv = find_dv(hmat, n, u);

	connect_checkNode_with_variableNode(hmat,n,u,cn_graph);
	connect_variableNode_with_checkNode(hmat,n,u,vn_graph);

	probability_array = assign_probability(0);

	srand(time(NULL));

	for (int outer_ind = 0; outer_ind < 101; outer_ind++)
	{
		int Nsim = 10000;

		for (int Ksim = 1; Ksim <= Nsim; Ksim++) // Loop for Monte - Carlo experiment
		{

			vector<int> original_signal(n, 0);     // Original message signal

			vector<int> signal_with_noise(n);     // Signal with noise (Recieved signal)

			for (int i = 0; i < n; i++)
			{
				float tpr = ((float)rand() / (RAND_MAX + 1)); // Random number generator function

				if (tpr >= probability_array[outer_ind])
				{
					signal_with_noise[i] = original_signal[i];
				}
				else
				{
					signal_with_noise[i] = -1;  // Set this as erasure bit
				}
					
				val_vn[i] = signal_with_noise[i];
			}

			int t_flag = 0;
			int zero_erasure_case = 1;
			int itr_cnt = 0;

			while (itr_cnt < 100)     // Maximum 100 iterations are allowed
			{						// after 100 iteration loop will be terminated automatically
				if(t_flag == 1)
				{
					break;
				}

				if(zero_erasure_case == u)
				{
					break;
				}

/****************************************  VN is sending message to CN  *****************************************/
/***********************************************  START  ********************************************************/
				for (int i = 0; i < n; i++)
				{
					int k = val_vn[i];

					int c1 = vn_graph[i][0].first;
					int c2 = vn_graph[i][1].first;
					int c3 = vn_graph[i][2].first;

					for (int j = 0; j < dc; j++)
					{
						if (cn_graph[c1 - 1][j].first == i + 1)
						{
							cn_graph[c1 - 1][j].second = k;
						}
					}
					for (int j = 0; j < dc; j++)
					{
						if (cn_graph[c2 - 1][j].first == i + 1)
						{
							cn_graph[c2 - 1][j].second = k;
						}
					}
					for (int j = 0; j < dc; j++)
					{
						if (cn_graph[c3 - 1][j].first == i + 1)
						{
							cn_graph[c3 - 1][j].second = k;
						}
					}
				}

/***********************************************  END  ********************************************************/


/****************************************  CN is sending message to VN  *****************************************/
/***********************************************  START  ********************************************************/


				t_flag = 1;
				zero_erasure_case = 0;

				for (int i = 0; i < u; i++)
				{
					int erasure_count = 0;

					for (auto it : cn_graph[i])
					{
						if (it.second == -1)
						{
							erasure_count++;
						}
					}

					if (erasure_count == 1) 
					{
						int cn_itr = 0;

						for (auto &it : cn_graph[i])
						{
							if (it.second == -1)
							{
								int t_vn;

								t_vn = it.first;

								if (cn_itr == 0)
								{
									val_vn[t_vn - 1] = (cn_graph[i][1].second + cn_graph[i][2].second + cn_graph[i][3].second) % 2;

									for (auto &vn_it : vn_graph[t_vn - 1])
									{
										if (vn_it.first == i + 1)
										{
											vn_it.second = (cn_graph[i][1].second + cn_graph[i][2].second + cn_graph[i][3].second) % 2;
										}
									}
								}
								else if (cn_itr == 1)
								{
									val_vn[t_vn - 1] = (cn_graph[i][0].second + cn_graph[i][2].second + cn_graph[i][3].second) % 2;

									for (auto &vn_it : vn_graph[t_vn - 1])
									{
										if (vn_it.first == i + 1)
										{
											vn_it.second = (cn_graph[i][0].second + cn_graph[i][2].second + cn_graph[i][3].second) % 2;
										}
									}
								}
								else if (cn_itr == 2)
								{
									val_vn[t_vn - 1] = (cn_graph[i][0].second + cn_graph[i][1].second + cn_graph[i][3].second) % 2;

									for (auto &vn_it : vn_graph[t_vn - 1])
									{
										if (vn_it.first == i + 1)
										{
											vn_it.second = (cn_graph[i][0].second + cn_graph[i][1].second + cn_graph[i][3].second) % 2;
										}
									}
								}
								else if (cn_itr == 3)
								{
									val_vn[t_vn - 1] = (cn_graph[i][0].second + cn_graph[i][1].second + cn_graph[i][2].second) % 2;

									for (auto &vn_it : vn_graph[t_vn - 1])
									{
										if (vn_it.first == i + 1)
										{
											vn_it.second = (cn_graph[i][0].second + cn_graph[i][1].second + cn_graph[i][2].second) % 2;
										}
									}
								}
								t_flag = 0;
							}
							cn_itr++;
						}
					}
					else if (erasure_count == 0)
					{
						zero_erasure_case++;
					}

				}

/***********************************************  END  ********************************************************/
				
				itr_cnt++;   // Increment the iteration number
			}

			t_flag = 0;

			for (int q = 0; q < n; q++)     // Checking the decoded signal with original signal
			{
				if (val_vn[q] != original_signal[q])
				{
					t_flag++;
					break;
				}
			}

			if (t_flag == 0)
			{
				correct[outer_ind] = correct[outer_ind] + 1;
			}
		}
	}

	cout << "Probability of Successful Decoding : " << endl;

	cout << endl;

	for (int i = 0; i < 101; i++)
	{
		cout << float(correct[i]) / 10000 << endl;      // Printing the probability of successful decoding
	}
}
