#include <bits/stdc++.h>
using namespace std;

int main()
{
    int n, u;

    u = 3792;
    n = 5056;

    vector<float> val_vn(n);
    vector<vector<pair<int, float>>> cn_graph(u);
    vector<vector<pair<int, float>>> vn_graph(n);
    vector<float> val_cn(3);
    vector<int> conv(31, 0);  // To store erasure bits

    float probability = 0.6;

    float constant_1, vnd_1, vnd_0;

    int **hmat = new int *[u];

    for (int i = 0; i < u; i++)
    {
        hmat[i] = new int[n];
    }

    ifstream fin;
    fin.open("H_matrix.txt");

    if (!fin)
    {
        cout << "Cannot open the file" << endl;
        exit(0);
    }

    int inRow = 0, inCol = 0;

    char data;
    while (!fin.eof()) 
    {
        fin >> data;

        if (inCol == n)
        {

            inCol = 0;
            inRow++;
        }

        hmat[inRow][inCol] = data - 48;
        inCol++;

        if (inRow == u - 1 && inCol == n)
        {
            break;
        }
    }
    fin.close();

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < u; j++)
        {
            if (hmat[j][i] == 1)
            {
                vn_graph[i].push_back({j + 1, -1});
            }
        }
    }

    for (int i = 0; i < u; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (hmat[i][j] == 1)
            {
                cn_graph[i].push_back({j + 1, -1});
            }
        }
    }

    srand(time(NULL));

    int Nsim = 1000;

    for (int Nsim_itr = 1; Nsim_itr <= Nsim; Nsim_itr++) // onte - Carlo Experiment for 1000 times
    {

        vector<int> original_signal(n, 0); // Original Signal

        vector<int> signal_with_noise(n); // Signal with noise

        for (int i = 0; i < n; i++)
        {
            float tpr = ((float)rand() / (RAND_MAX + 1)); 

            if (tpr > probability)
            {
                signal_with_noise[i] = original_signal[i];
            }
            else
            {
                signal_with_noise[i] = -1; 
            }

            if (signal_with_noise[i] == 0)
            {
                val_vn[i] = 0;

                for (int ci = 0; ci < 3; ci++)
                {
                    vn_graph[i][ci].second = 0;
                }
            }
            else
            {
                val_vn[i] = 0.5;

                for (int ci = 0; ci < 3; ci++)
                {
                    vn_graph[i][ci].second = 0.5;
                }

                conv[0]++;
            }
        }

        int itr_cnt = 0;

        while (itr_cnt < 30)   // Maximum 30 iterations are allowed
        {
            // VN to CN

            for (int i = 0; i < n; i++)
            {
                int c1 = vn_graph[i][0].first;
                int c2 = vn_graph[i][1].first;
                int c3 = vn_graph[i][2].first;

                for (int j = 0; j < 4; j++)
                {
                    if (cn_graph[c1 - 1][j].first == i + 1)
                    {
                        cn_graph[c1 - 1][j].second = vn_graph[i][0].second;
                    }
                }
                for (int j = 0; j < 4; j++)
                {
                    if (cn_graph[c2 - 1][j].first == i + 1)
                    {
                        cn_graph[c2 - 1][j].second = vn_graph[i][1].second;
                    }
                }
                for (int j = 0; j < 4; j++)
                {
                    if (cn_graph[c3 - 1][j].first == i + 1)
                    {
                        cn_graph[c3 - 1][j].second = vn_graph[i][2].second;
                    }
                }
            }

            // CN to VN

            for (int i = 0; i < u; i++)
            {
                int erasure_count = 0;

                for (auto it : cn_graph[i])
                {
                    if (it.second == 0.5)
                    {
                        erasure_count++;
                    }
                }

                if (erasure_count == 1)
                {
                    int cn_itr = 0;

                    for (auto &it : cn_graph[i])
                    {
                        if (it.second == 0.5)
                        {
                            int t_vn;

                            t_vn = it.first;

                            if (cn_itr == 0)
                            {
                                for (auto &vn_it : vn_graph[t_vn - 1])
                                {
                                    if (vn_it.first == i + 1)
                                    {
                                        vn_it.second = (0.5 - 0.5 * (1 - 2 * cn_graph[i][1].second) * (1 - 2 * cn_graph[i][2].second) * (1 - 2 * cn_graph[i][3].second));
                                    }
                                }
                            }
                            else if (cn_itr == 1)
                            {
                                for (auto &vn_it : vn_graph[t_vn - 1])
                                {
                                    if (vn_it.first == i + 1)
                                    {
                                        vn_it.second = (0.5 - 0.5 * (1 - 2 * cn_graph[i][0].second) * (1 - 2 * cn_graph[i][2].second) * (1 - 2 * cn_graph[i][3].second));
                                    }
                                }
                            }
                            else if (cn_itr == 2)
                            {
                                for (auto &vn_it : vn_graph[t_vn - 1])
                                {
                                    if (vn_it.first == i + 1)
                                    {
                                        vn_it.second = (0.5 - 0.5 * (1 - 2 * cn_graph[i][0].second) * (1 - 2 * cn_graph[i][1].second) * (1 - 2 * cn_graph[i][3].second));
                                    }
                                }
                            }
                            else if (cn_itr == 3)
                            {
                                for (auto &vn_it : vn_graph[t_vn - 1])
                                {
                                    if (vn_it.first == i + 1)
                                    {
                                        vn_it.second = (0.5 - 0.5 * (1 - 2 * cn_graph[i][0].second) * (1 - 2 * cn_graph[i][1].second) * (1 - 2 * cn_graph[i][2].second));
                                    }
                                }
                            }
                        }

                        cn_itr++;
                    }
                }
            }

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    val_cn[j] = vn_graph[i][j].second;
                }

                if (val_cn[0] != 0 && val_cn[1] != 9 && val_cn[2] != 0 && val_vn[i] != 0)
                {
                    ++conv[itr_cnt + 1];
                }

                for (int j = 0; j < 3; j++)
                {
                    vnd_1 = val_vn[i] * val_cn[(j + 1) % 3] * val_cn[(j + 2) % 3];

                    vnd_0 = (1 - val_vn[i]) * (1 - val_cn[(j + 1) % 3]) * (1 - val_cn[(j + 2) % 3]);

                    constant_1 = 1 / (vnd_0 + vnd_1);

                    vn_graph[i][j].second = constant_1 * vnd_1;
                }
            }

            itr_cnt++;
        }
    }   

    for(int i=0;i<30;i++)
    {
        cout<<conv[i]*(1.0)/Nsim<<endl;
    }
}
