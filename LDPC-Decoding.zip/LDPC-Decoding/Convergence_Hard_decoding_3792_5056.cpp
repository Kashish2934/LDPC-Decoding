#include <bits/stdc++.h>        // This code will give the number of erasure bit per iteration
using namespace std;

int main()
{
    int n, u;

    u = 3792; // Row of H matrix
    n = 5056; // Column of H matrix

    vector<int> val_vn(n);

    vector<vector<pair<int, int>>> cn_graph(u);
    vector<vector<pair<int, int>>> vn_graph(n);

    vector<int> conv(51, 0);

    float probability = 0.70;

    int **hmat = new int *[u];

    for (int i = 0; i < u; i++)
    {
        hmat[i] = new int[n];
    }

    ifstream fin;
    fin.open("H_matrix.txt"); // Reading the H matrix from txt file

    if (!fin) // Error in opening the file
    {
        cout << "Cannot open the file" << endl;
        exit(0);
    }

    int inRow = 0, inCol = 0;

    char data;
    while (!fin.eof())
    {
        fin >> data;

        if (inCol == n)
        {

            inCol = 0;
            inRow++;
        }

        hmat[inRow][inCol] = data - 48;
        inCol++;

        if (inRow == u - 1 && inCol == n)
        {
            break;
        }
    }
    fin.close(); // Close the file which was opened after successfully reading H matrix

    int dv = 0;
    int dc = 0;

    for (int i = 0; i < 1; i++) // Finding the degree of check node
    {
        for (int j = 0; j < n; j++)
        {
            if (hmat[i][j] == 1)
            {
                dc++;
            }
        }
    }

    for (int i = 0; i < 1; i++) // Finding the degree of variable node
    {
        for (int j = 0; j < u; j++)
        {
            if (hmat[j][i] == 1)
            {
                dv++;
            }
        }
    }

    for (int i = 0; i < n; i++) // Connect variable node with the check node
    {
        for (int j = 0; j < u; j++)
        {
            if (hmat[j][i] == 1)
            {
                vn_graph[i].push_back({j + 1, -1});
            }
        }
    }

    for (int i = 0; i < u; i++) // Connect check node with the variable node
    {
        for (int j = 0; j < n; j++)
        {
            if (hmat[i][j] == 1)
            {
                cn_graph[i].push_back({j + 1, -1});
            }
        }
    }

    srand(time(NULL));

    int Nsim = 1000;

    for (int Nsim_itr = 1; Nsim_itr <= Nsim; Nsim_itr++) // Loop for Monte - Carlo experiment
    {

        vector<int> original_signal(n, 0); // Original message signal

        vector<int> signal_with_noise(n); // Signal with noise (Recieved signal)

        for (int i = 0; i < n; i++)
        {
            float tpr = ((float)rand() / (RAND_MAX + 1)); // Random number generator function

            if (tpr >= probability)
            {
                signal_with_noise[i] = original_signal[i];
            }
            else
            {
                signal_with_noise[i] = -1; // if random number < probability_array[outer_ind] then it would be erasure
            }

            val_vn[i] = signal_with_noise[i];

            if (val_vn[i] == -1)
            {
                conv[0]++;
            }
        }

        int itr_cnt = 0;

        while (itr_cnt < 50) // Maximum 50 iterations are allowed
        {                    // after 50 iteration loop will be terminated automatically

            for (int i = 0; i < n; i++)
            {
                int val = val_vn[i];

                int c1 = vn_graph[i][0].first;
                int c2 = vn_graph[i][1].first;
                int c3 = vn_graph[i][2].first;

                for (int j = 0; j < dc; j++)
                {
                    if (cn_graph[c1 - 1][j].first == i + 1)
                    {
                        cn_graph[c1 - 1][j].second = val;
                    }
                }
                for (int j = 0; j < dc; j++)
                {
                    if (cn_graph[c2 - 1][j].first == i + 1)
                    {
                        cn_graph[c2 - 1][j].second = val;
                    }
                }
                for (int j = 0; j < dc; j++)
                {
                    if (cn_graph[c3 - 1][j].first == i + 1)
                    {
                        cn_graph[c3 - 1][j].second = val;
                    }
                }
            }

            for (int i = 0; i < u; i++)
            {
                int erasure_count = 0;

                for (auto it : cn_graph[i])
                {
                    if (it.second == -1)
                    {
                        erasure_count++;
                    }
                }

                if (erasure_count == 1)
                {
                    int cn_itr = 0;

                    for (auto &it : cn_graph[i])
                    {
                        if (it.second == -1)
                        {
                            int t_vn;

                            t_vn = it.first;

                            if (cn_itr == 0)
                            {
                                val_vn[t_vn - 1] = (cn_graph[i][1].second + cn_graph[i][2].second + cn_graph[i][3].second) % 2;

                                for (auto &vn_it : vn_graph[t_vn - 1])
                                {
                                    if (vn_it.first == i + 1)
                                    {
                                        vn_it.second = (cn_graph[i][1].second + cn_graph[i][2].second + cn_graph[i][3].second) % 2;
                                    }
                                }
                            }
                            else if (cn_itr == 1)
                            {
                                val_vn[t_vn - 1] = (cn_graph[i][0].second + cn_graph[i][2].second + cn_graph[i][3].second) % 2;

                                for (auto &vn_it : vn_graph[t_vn - 1])
                                {
                                    if (vn_it.first == i + 1)
                                    {
                                        vn_it.second = (cn_graph[i][0].second + cn_graph[i][2].second + cn_graph[i][3].second) % 2;
                                    }
                                }
                            }
                            else if (cn_itr == 2)
                            {
                                val_vn[t_vn - 1] = (cn_graph[i][0].second + cn_graph[i][1].second + cn_graph[i][3].second) % 2;

                                for (auto &vn_it : vn_graph[t_vn - 1])
                                {
                                    if (vn_it.first == i + 1)
                                    {
                                        vn_it.second = (cn_graph[i][0].second + cn_graph[i][1].second + cn_graph[i][3].second) % 2;
                                    }
                                }
                            }
                            else if (cn_itr == 3)
                            {
                                val_vn[t_vn - 1] = (cn_graph[i][0].second + cn_graph[i][1].second + cn_graph[i][2].second) % 2;

                                for (auto &vn_it : vn_graph[t_vn - 1])
                                {
                                    if (vn_it.first == i + 1)
                                    {
                                        vn_it.second = (cn_graph[i][0].second + cn_graph[i][1].second + cn_graph[i][2].second) % 2;
                                    }
                                }
                            }
                        }
                        cn_itr++;
                    }
                }
            }

            for (int i = 0; i < n; i++)
            {
                if (val_vn[i] == -1) // After t th iteration if VN is still erasure then, increase a number in convergence
                {
                    conv[itr_cnt + 1]++;
                }
            }

            itr_cnt++; // Increment the iteration index
        }
    }

    for (int i = 0; i < 51; i++)
    {
        cout << (float)conv[i] / (Nsim*n) << endl;
    }
}
