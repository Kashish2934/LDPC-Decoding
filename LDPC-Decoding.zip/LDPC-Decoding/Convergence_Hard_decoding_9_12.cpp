#include <bits/stdc++.h>         // This code will give the number of erasure bit per iteration
using namespace std;

int find_dc(vector<vector<int>> &hmat, int n, int u) // This function will find the degree of check node from given H matrix
{
    int dc = 0;

    for (int i = 0; i < 1; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (hmat[i][j] == 1)
            {
                dc++;
            }
        }
    }

    return dc;
}

int find_dv(vector<vector<int>> &hmat, int n, int u) // This function will find the degree of variable node from given H matrix
{
    int dv = 0;

    for (int i = 0; i < 1; i++)
    {
        for (int j = 0; j < u; j++)
        {
            if (hmat[j][i] == 1)
            {
                dv++;
            }
        }
    }

    return dv;
}

void connect_checkNode_with_variableNode(vector<vector<int>> &hmat, int n, int u, vector<vector<pair<int, int>>> &cn_graph)
{ // This function is for connection of check node with variable node
    for (int i = 0; i < u; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (hmat[i][j] == 1)
            {
                cn_graph[i].push_back({j + 1, -1});
            }
        }
    }
}

void connect_variableNode_with_checkNode(vector<vector<int>> &hmat, int n, int u, vector<vector<pair<int, int>>> &vn_graph)
{ // This function is for connection of variable node with check node
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < u; j++)
        {
            if (hmat[j][i] == 1)
            {
                vn_graph[i].push_back({j + 1, -1});
            }
        }
    }
}

int main()
{
    int n, u;

    cout << "Enter Row(u) and Column(n) of H matrix : " << endl;

    cin >> u >> n;

    vector<vector<int>> hmat(u, vector<int>(n, 0));

    cout << "Enter H matrix : " << endl;
    // Taking input of H matrix
    for (int i = 0; i < u; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cin >> hmat[i][j];
        }
    }

    int dc = find_dc(hmat, n, u);
    int dv = find_dv(hmat, n, u);

    vector<int> val_vn(n);

    vector<vector<pair<int, int>>> cn_graph(u);
    vector<vector<pair<int, int>>> vn_graph(n);

    vector<int> conv(51, 0);

    float probability = 0.2;

    connect_checkNode_with_variableNode(hmat, n, u, cn_graph);

    connect_variableNode_with_checkNode(hmat, n, u, vn_graph);

    srand(time(NULL));

    int Nsim = 10000;

    for (int Ksim = 1; Ksim <= Nsim; Ksim++)
    {

        vector<int> original_signal(n, 0); // Original message signal

        vector<int> signal_with_noise(n); // Signal with noise (Recieved signal)

        for (int i = 0; i < n; i++)
        {
            float tpr = ((float)rand() / (RAND_MAX + 1)); // Random number generator function

            if (tpr >= probability)
            {
                signal_with_noise[i] = original_signal[i];
            }
            else
            {
                signal_with_noise[i] = -1; // if random number < probability_array[outer_ind] then it would be erasure
            }

            val_vn[i] = signal_with_noise[i];

            if (val_vn[i] == -1)
            {
                conv[0]++;
            }
        }

        int itr_cnt = 0;

        while (itr_cnt < 50) // Maximum 50 iterations are allowed
        {                    // after 50 iteration loop will be terminated automatically

            /****************************************  VN is sending message to CN  *****************************************/
            /***********************************************  START  ********************************************************/
            for (int i = 0; i < n; i++)
            {
                int k = val_vn[i];

                int c1 = vn_graph[i][0].first;
                int c2 = vn_graph[i][1].first;
                int c3 = vn_graph[i][2].first;

                for (int j = 0; j < dc; j++)
                {
                    if (cn_graph[c1 - 1][j].first == i + 1)
                    {
                        cn_graph[c1 - 1][j].second = k;
                    }
                }
                for (int j = 0; j < dc; j++)
                {
                    if (cn_graph[c2 - 1][j].first == i + 1)
                    {
                        cn_graph[c2 - 1][j].second = k;
                    }
                }
                for (int j = 0; j < dc; j++)
                {
                    if (cn_graph[c3 - 1][j].first == i + 1)
                    {
                        cn_graph[c3 - 1][j].second = k;
                    }
                }
            }

            /***********************************************  END  ********************************************************/

            /****************************************  CN is sending message to VN  *****************************************/
            /***********************************************  START  ********************************************************/

            for (int i = 0; i < u; i++)
            {
                int erasure_count = 0;

                for (auto it : cn_graph[i])
                {
                    if (it.second == -1)
                    {
                        erasure_count++;
                    }
                }

                if (erasure_count == 1)
                {
                    int cn_itr = 0;

                    for (auto &it : cn_graph[i])
                    {
                        if (it.second == -1)
                        {
                            int t_vn;

                            t_vn = it.first;

                            if (cn_itr == 0)
                            {
                                val_vn[t_vn - 1] = (cn_graph[i][1].second + cn_graph[i][2].second + cn_graph[i][3].second) % 2;

                                for (auto &vn_it : vn_graph[t_vn - 1])
                                {
                                    if (vn_it.first == i + 1)
                                    {
                                        vn_it.second = (cn_graph[i][1].second + cn_graph[i][2].second + cn_graph[i][3].second) % 2;
                                    }
                                }
                            }
                            else if (cn_itr == 1)
                            {
                                val_vn[t_vn - 1] = (cn_graph[i][0].second + cn_graph[i][2].second + cn_graph[i][3].second) % 2;

                                for (auto &vn_it : vn_graph[t_vn - 1])
                                {
                                    if (vn_it.first == i + 1)
                                    {
                                        vn_it.second = (cn_graph[i][0].second + cn_graph[i][2].second + cn_graph[i][3].second) % 2;
                                    }
                                }
                            }
                            else if (cn_itr == 2)
                            {
                                val_vn[t_vn - 1] = (cn_graph[i][0].second + cn_graph[i][1].second + cn_graph[i][3].second) % 2;

                                for (auto &vn_it : vn_graph[t_vn - 1])
                                {
                                    if (vn_it.first == i + 1)
                                    {
                                        vn_it.second = (cn_graph[i][0].second + cn_graph[i][1].second + cn_graph[i][3].second) % 2;
                                    }
                                }
                            }
                            else if (cn_itr == 3)
                            {
                                val_vn[t_vn - 1] = (cn_graph[i][0].second + cn_graph[i][1].second + cn_graph[i][2].second) % 2;

                                for (auto &vn_it : vn_graph[t_vn - 1])
                                {
                                    if (vn_it.first == i + 1)
                                    {
                                        vn_it.second = (cn_graph[i][0].second + cn_graph[i][1].second + cn_graph[i][2].second) % 2;
                                    }
                                }
                            }
                        }

                        cn_itr++;
                    }
                }
            }

            for (int i = 0; i < n; i++)
            {
                if (val_vn[i] == -1) // After t th iteration if VN is still erasure then, increase a number in convergence
                {
                    conv[itr_cnt + 1]++;
                }
            }

            itr_cnt++; // Increment the iteration number
        }
    }

    for (int i = 0; i < 51; i++)
    {
        cout << float(conv[i]) / (Nsim*n) << endl;
    }
}
