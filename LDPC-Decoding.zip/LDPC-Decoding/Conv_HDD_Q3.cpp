#include <bits/stdc++.h>
using namespace std;

int main()
{
    int n, u;

    u = 3000; // Row of H matrix
    n = 5000; // Column of H matrix

    vector<int> err(101, 0);
    vector<int> correct(101, 0);

    vector<int> val_vn(n);

    vector<vector<pair<int, int>>> cn_graph(u);
    vector<vector<pair<int, int>>> vn_graph(n);

    vector<int> conv(31, 0);    // To store erasure bit

    float probability = 0.1;

    int **hmat = new int *[u];

    for (int i = 0; i < u; i++)
    {
        hmat[i] = new int[n];
    }

    ifstream fin;
    fin.open("h_matrix_q3.txt"); // Reading the H matrix from .txt file

    if (!fin)
    {
        cout << "Cannot open the file" << endl; // Error in opening the txt file
        exit(0);
    }

    int inRow = 0, inCol = 0;

    char data;
    while (!fin.eof())
    {
        fin >> data;

        if (inCol == n)
        {

            inCol = 0;
            inRow++;
        }

        hmat[inRow][inCol] = data - 48;
        inCol++;

        if (inRow == u - 1 && inCol == n)
        {
            break;
        }
    }

    fin.close(); // Close the file which was opened after successfully reading H matrix

    int dv = 0;
    int dc = 0;

    for (int i = 0; i < 1; i++) // Finding the degree of check node
    {
        for (int j = 0; j < n; j++)
        {
            if (hmat[i][j] == 1)
            {
                dc++;
            }
        }
    }

    for (int i = 0; i < 1; i++) // Finding the degree of variable node
    {
        for (int j = 0; j < u; j++)
        {
            if (hmat[j][i] == 1)
            {
                dv++;
            }
        }
    }

    for (int i = 0; i < n; i++) // Connect variable node with the check node
    {
        for (int j = 0; j < u; j++)
        {
            if (hmat[j][i] == 1)
            {
                vn_graph[i].push_back({j + 1, -1});
            }
        }
    }

    for (int i = 0; i < u; i++) // Connect check node with the variable node
    {
        for (int j = 0; j < n; j++)
        {
            if (hmat[i][j] == 1)
            {
                cn_graph[i].push_back({j + 1, -1});
            }
        }
    }

    srand(time(NULL));

    int Nsim = 1000;

    for (int Ksim = 1; Ksim <= Nsim; Ksim++) // Loop for Monte - Carlo experiment
    {

        vector<int> original_signal(n, 0); // Original message signal
        vector<int> signal_with_noise(n);  // Message signal with noise (Recieved Signal)

        for (int i = 0; i < n; i++)
        {
            float tpr = ((float)rand() / (RAND_MAX + 1)); // Generating a random number between 0 to 1

            if (tpr >= probability)
            {
                signal_with_noise[i] = original_signal[i];
            }
            else
            {
                signal_with_noise[i] = -1; // if random number < probability_array[outer_ind] then it would be erasure
            }

            val_vn[i] = signal_with_noise[i];

            if (val_vn[i] == -1)
            {
                conv[0]++;     // Increment the number of erasure bit
            }
        }

        int itr_cnt = 0;

        while (itr_cnt < 30) // Maximum 30 iterations are allowed
        {                    // after 30 iteration loop will be terminated automatically
            for (int i = 0; i < n; i++)
            {
                int val = val_vn[i];

                int chk1 = vn_graph[i][0].first;
                int chk2 = vn_graph[i][1].first;
                int chk3 = vn_graph[i][2].first;

                for (int j = 0; j < dc; j++)
                {
                    if (cn_graph[chk1 - 1][j].first == i + 1)
                    {
                        cn_graph[chk1 - 1][j].second = val;
                    }
                }
                for (int j = 0; j < dc; j++)
                {
                    if (cn_graph[chk2 - 1][j].first == i + 1)
                    {
                        cn_graph[chk2 - 1][j].second = val;
                    }
                }
                for (int j = 0; j < dc; j++)
                {
                    if (cn_graph[chk3 - 1][j].first == i + 1)
                    {
                        cn_graph[chk3 - 1][j].second = val;
                    }
                }
            }

            for (int i = 0; i < u; i++)
            {
                int erasure_count = 0;

                for (auto it : cn_graph[i])
                {
                    if (it.second == -1)
                    {
                        erasure_count++;
                    }
                }

                if (erasure_count == 1)
                {
                    int cn_itr = 0;

                    for (auto &it : cn_graph[i])
                    {
                        if (it.second == -1)
                        {
                            int t_vn;

                            t_vn = it.first;

                            if (cn_itr == 0)
                            {
                                val_vn[t_vn - 1] = (cn_graph[i][1].second + cn_graph[i][2].second + cn_graph[i][3].second + cn_graph[i][4].second) % 2;

                                for (auto &vn_it : vn_graph[t_vn - 1])
                                {
                                    if (vn_it.first == i + 1)
                                    {
                                        vn_it.second = (cn_graph[i][1].second + cn_graph[i][2].second + cn_graph[i][3].second + cn_graph[i][4].second) % 2;
                                    }
                                }
                            }
                            else if (cn_itr == 1)
                            {
                                val_vn[t_vn - 1] = (cn_graph[i][0].second + cn_graph[i][2].second + cn_graph[i][3].second + cn_graph[i][4].second) % 2;

                                for (auto &vn_it : vn_graph[t_vn - 1])
                                {
                                    if (vn_it.first == i + 1)
                                    {
                                        vn_it.second = (cn_graph[i][0].second + cn_graph[i][2].second + cn_graph[i][3].second + cn_graph[i][4].second) % 2;
                                    }
                                }
                            }
                            else if (cn_itr == 2)
                            {
                                val_vn[t_vn - 1] = (cn_graph[i][0].second + cn_graph[i][1].second + cn_graph[i][3].second + cn_graph[i][4].second) % 2;

                                for (auto &vn_it : vn_graph[t_vn - 1])
                                {
                                    if (vn_it.first == i + 1)
                                    {
                                        vn_it.second = (cn_graph[i][0].second + cn_graph[i][1].second + cn_graph[i][3].second + cn_graph[i][4].second) % 2;
                                    }
                                }
                            }
                            else if (cn_itr == 3)
                            {
                                val_vn[t_vn - 1] = (cn_graph[i][0].second + cn_graph[i][1].second + cn_graph[i][2].second + cn_graph[i][4].second) % 2;

                                for (auto &vn_it : vn_graph[t_vn - 1])
                                {
                                    if (vn_it.first == i + 1)
                                    {
                                        vn_it.second = (cn_graph[i][0].second + cn_graph[i][1].second + cn_graph[i][2].second + cn_graph[i][4].second) % 2;
                                    }
                                }
                            }
                            else if (cn_itr == 4)
                            {
                                val_vn[t_vn - 1] = (cn_graph[i][0].second + cn_graph[i][1].second + cn_graph[i][2].second + cn_graph[i][3].second) % 2;

                                for (auto &vn_it : vn_graph[t_vn - 1])
                                {
                                    if (vn_it.first == i + 1)
                                    {
                                        vn_it.second = (cn_graph[i][0].second + cn_graph[i][1].second + cn_graph[i][2].second + cn_graph[i][3].second) % 2;
                                    }
                                }
                            }
                        }

                        cn_itr++;
                    }
                }
            }

            for (int i = 0; i < n; i++)
            {
                if (val_vn[i] == -1) // After t th iteration if VN is still erasure then, increase a number in convergence
                {
                    conv[itr_cnt + 1]++;
                }
            }

            itr_cnt++;
        }
    }

    for (int i = 0; i < 30; i++)
    {
        cout << (float)conv[i] / Nsim << endl;
    }
}
